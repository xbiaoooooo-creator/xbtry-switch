import { useId, type ReactNode } from "react";
import type { TFunction } from "i18next";
import { RefreshCw } from "lucide-react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import { HoverTip } from "@/components/ui/hover-tip";
import {
  ResetSlot,
  TONE_FILL,
  TONE_TEXT,
  TonedText,
  useNow,
} from "@/components/quota/QuotaLines";
import { useQuotaDisplay } from "@/components/quota/useQuotaDisplay";
import {
  QuotaBreakdownChevron,
  QuotaBreakdownRow,
} from "@/components/quota/QuotaBreakdown";
import {
  barPercent,
  countdownStr,
  formatRelativeTime,
  lineHint,
  tierLine,
  type QuotaDisplay,
  type QuotaLine,
} from "@/components/quota/quotaRules";
import {
  quotaFailureReason,
  quotaRows,
} from "@/components/SubscriptionQuotaFooter";
import type { SubscriptionQuota } from "@/types/subscription";
import { useCopilotQuota } from "@/lib/query/copilot";
import {
  useAgyAccountQuota,
  useClaudeAccountQuota,
  useKimiAccountQuota,
  useXaiOauthQuotaByAccountId,
} from "@/lib/query/subscription";
import { extractErrorMessage } from "@/utils/errorUtils";

export interface AccountQuotaRow {
  label: string;
  line: QuotaLine;
}

/** 额度列要画的东西：成功按档画条；查询失败写「额度查询失败」+ 原因；查成功但没有额度时写一句灰字；null 表示不显示 */
export type AccountQuotaState =
  | { kind: "rows"; rows: AccountQuotaRow[] }
  | { kind: "failed"; reason: string }
  | { kind: "note"; text: string }
  | { kind: "loading" }
  | null;

interface AccountQuotaColumnProps {
  /** 账号名，拼进刷新按钮的无障碍名字 */
  login: string;
  state: AccountQuotaState;
  queriedAt?: number | null;
  loading: boolean;
  onRefresh: () => void;
}

/**
 * 授权中心账号行右侧的额度（v7 Auth 画板）：额度条（条和数字按设置写剩余或已用，
 * 平时 --chart-1；不到 20% 换 warning，用完换 danger）+ 84 宽的「x 分钟前 ↻」。
 * 档名、数值、倒计时三格定宽，倒计时格没有也留着；整列宽度只随分组卡片宽度变
 * （.auth-quota-col，见 index.css），各账号、各分组的条起点和长度一致。
 * 打开页面时查一次，不轮询；↻ 手动重查。
 */
export function AccountQuotaColumn({
  login,
  state,
  queriedAt,
  loading,
  onRefresh,
}: AccountQuotaColumnProps) {
  const { t } = useTranslation();
  const now = useNow(
    Boolean(queriedAt) ||
      (state?.kind === "rows" && state.rows.some(({ line }) => line.resetsAt)),
  );
  if (!state) return null;
  // 倒计时格始终留着（没有重置时间就空着），别的号的条才不会因此变宽或挪位
  const resetCell = (line: QuotaLine) => (
    <ResetSlot countdown={countdownStr(line.resetsAt, now)} className="" />
  );

  return (
    <>
      <div className="auth-quota-col flex shrink-0 flex-col gap-0.5">
        {state.kind === "rows" &&
          state.rows.map(({ label, line }) =>
            line.breakdown ? (
              <QuotaBreakdownRow
                key={line.key}
                line={line}
                breakdown={line.breakdown}
                className={ROW_CLASS}
              >
                <QuotaRowCells
                  label={label}
                  line={line}
                  trailing={<QuotaBreakdownChevron />}
                />
                {resetCell(line)}
              </QuotaBreakdownRow>
            ) : (
              <div
                key={line.key}
                title={lineHint(t, line, now)}
                className={ROW_CLASS}
              >
                <QuotaRowCells label={label} line={line} />
                {resetCell(line)}
              </div>
            ),
          )}
        {state.kind === "failed" && (
          <>
            <span className="h-[18px] text-caption font-medium text-danger-text">
              {t("quota.failed", { defaultValue: "额度查询失败" })}
            </span>
            <span
              className="truncate text-caption text-fg-3"
              title={state.reason}
            >
              {state.reason}
            </span>
          </>
        )}
        {state.kind === "note" && (
          // 写在额度行数值（「剩余 91%」）那一格：右边让出倒计时格（52）和间距（8），和别的号的数值对齐
          <span className="me-[60px] self-end text-caption text-fg-3">
            {state.text}
          </span>
        )}
        {state.kind === "loading" && (
          <span className="text-caption text-fg-3">
            {t("authCenter.quota.loading", { defaultValue: "正在查询额度…" })}
          </span>
        )}
      </div>
      <QuotaRefreshCell
        login={login}
        queriedAt={queriedAt}
        loading={loading}
        onRefresh={onRefresh}
      />
    </>
  );
}

interface QuotaRefreshCellProps {
  /** 账号名，拼进刷新按钮的无障碍名字 */
  login: string;
  queriedAt?: number | null;
  loading: boolean;
  onRefresh: () => void;
}

/**
 * 额度列右边 84 宽的「x 分钟前 ↻」。各服务的账号行共用，刷新按钮的位置和样式一致；
 * 不是额度条的服务（DeepSeek 账号的余额）也直接用它。
 */
export function QuotaRefreshCell({
  login,
  queriedAt,
  loading,
  onRefresh,
}: QuotaRefreshCellProps) {
  const { t } = useTranslation();
  const now = useNow(Boolean(queriedAt));
  const agoId = useId();
  const ago = queriedAt ? formatRelativeTime(queriedAt, now, t) : "";
  const agoText = loading
    ? t("authCenter.quota.updating", { defaultValue: "更新中…" })
    : ago;

  return (
    <div className="flex w-[84px] shrink-0 items-center justify-end gap-0.5 whitespace-nowrap text-caption text-fg-3">
      <span id={agoId} className="truncate">
        {agoText}
      </span>
      <HoverTip
        content={t("authCenter.quota.refresh", { defaultValue: "刷新额度" })}
      >
        <button
          type="button"
          aria-label={t("authCenter.quota.refreshAria", {
            defaultValue: "刷新 {{login}} 的额度",
            login,
          })}
          aria-disabled={loading}
          aria-describedby={loading ? agoId : undefined}
          onClick={() => {
            if (!loading) onRefresh();
          }}
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-control text-fg-2 transition-colors hover:bg-subtle hover:text-fg-1 aria-disabled:opacity-45 aria-disabled:hover:bg-transparent"
        >
          <RefreshCw
            className={cn(
              "h-[13px] w-[13px]",
              loading && "motion-safe:animate-spin",
            )}
            strokeWidth={1.5}
          />
        </button>
      </HoverTip>
    </div>
  );
}

const ROW_CLASS = "flex h-[18px] items-center gap-2 text-caption";

/** 一行额度：档名 + 额度条（或一句说明）+ 剩余 */
function QuotaRowCells({
  label,
  line,
  trailing,
}: {
  label: string;
  line: QuotaLine;
  /** 跟在说明文字后面的小图标（可点开的行用） */
  trailing?: ReactNode;
}) {
  const width = barPercent(line);
  const value = line.value ?? line.text;
  return (
    <>
      {/* 定宽：「Claude/GPT 每周」这类长档名不再把条挤短；更长的截断，悬停看全名 */}
      <span
        title={label}
        className="w-[112px] shrink-0 truncate whitespace-nowrap text-fg-2"
      >
        {label}
      </span>
      {line.caption ? (
        <span className="flex min-w-0 flex-1 items-center gap-0.5 text-fg-3">
          <span className="truncate">{line.caption}</span>
          {trailing}
        </span>
      ) : (
        <span
          role="meter"
          aria-label={`${label}: ${value}`}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(width)}
          className="relative h-1 min-w-0 flex-1 overflow-hidden rounded-full bg-chart-grid"
        >
          <span
            className={cn(
              "absolute inset-y-0 start-0 rounded-full",
              TONE_FILL[line.tone],
            )}
            style={{ width: `${width}%` }}
          />
        </span>
      )}
      {/* 旁边已有额度条，正常时数值不上色 */}
      {/* 64 宽放得下「剩余 100%」，和「剩余 99%」右边对齐 */}
      <span className="w-16 shrink-0 whitespace-nowrap text-end tabular-nums text-fg-1">
        <TonedText
          text={value}
          line={line}
          className={line.tone === "normal" ? "" : TONE_TEXT[line.tone]}
        />
      </span>
    </>
  );
}

/** SubscriptionQuota（ChatGPT / xAI 账号的订阅额度）→ 额度列状态 */
export function subscriptionQuotaState(
  t: TFunction,
  quota: SubscriptionQuota | undefined,
  loading: boolean,
  locale: string,
  display: QuotaDisplay = "left",
): AccountQuotaState {
  if (!quota) return loading ? { kind: "loading" } : null;
  // 没有凭据 / 凭据解析失败：和供应商卡片一样不显示
  if (
    quota.credentialStatus === "not_found" ||
    quota.credentialStatus === "parse_error"
  ) {
    return null;
  }
  if (!quota.success) {
    return {
      kind: "failed",
      reason: quotaFailureReason(t, quota),
    };
  }
  const rows = quotaRows(t, quota, locale, { display });
  return rows.length > 0 ? { kind: "rows", rows } : null;
}

/** GitHub Copilot 账号的高级请求额度（copilot_get_usage_for_account） */
export function CopilotAccountQuota({
  accountId,
  login,
}: {
  accountId: string;
  login: string;
}) {
  const { t } = useTranslation();
  const display = useQuotaDisplay();
  const query = useCopilotQuota(accountId, { enabled: true, autoQuery: false });
  const { data: quota, isFetching: loading } = query;

  let state: AccountQuotaState;
  if (quota?.success) {
    const label = t("subscription.copilotPremium");
    state =
      quota.tiers.length > 0
        ? {
            kind: "rows",
            rows: quota.tiers.map((tier) => ({
              label,
              line: tierLine(t, tier, label, { display }),
            })),
          }
        : null;
  } else if (quota) {
    state = {
      kind: "failed",
      reason: quota.error || t("subscription.queryFailed"),
    };
  } else if (query.isError) {
    state = {
      kind: "failed",
      reason: extractErrorMessage(query.error) || t("subscription.queryFailed"),
    };
  } else {
    state = loading ? { kind: "loading" } : null;
  }

  return (
    <AccountQuotaColumn
      login={login}
      state={state}
      queriedAt={quota?.queriedAt ?? null}
      loading={loading}
      onRefresh={() => void query.refetch()}
    />
  );
}

/** xAI 账号的订阅额度（get_xai_oauth_quota(accountId)） */
export function XaiAccountQuota({
  accountId,
  login,
}: {
  accountId: string;
  login: string;
}) {
  const { t, i18n } = useTranslation();
  const display = useQuotaDisplay();
  const {
    data: quota,
    isFetching: loading,
    refetch,
  } = useXaiOauthQuotaByAccountId(accountId, {
    enabled: true,
    autoQuery: false,
  });
  return (
    <AccountQuotaColumn
      login={login}
      state={subscriptionQuotaState(t, quota, loading, i18n.language, display)}
      queriedAt={quota?.queriedAt ?? null}
      loading={loading}
      onRefresh={() => void refetch()}
    />
  );
}

/** Kimi 官方账号的剩余额度（kimi_oauth_quota(accountId)，不用先切号） */
export function KimiAccountQuota({
  accountId,
  login,
}: {
  accountId: string;
  login: string;
}) {
  const { t, i18n } = useTranslation();
  const display = useQuotaDisplay();
  const {
    data: quota,
    isFetching: loading,
    refetch,
  } = useKimiAccountQuota(accountId, { enabled: true, autoQuery: false });
  const state = subscriptionQuotaState(
    t,
    quota,
    loading,
    i18n.language,
    display,
  );
  return (
    <AccountQuotaColumn
      login={login}
      // 没订阅 Kimi Code 的号，额度接口返回空对象：查成功但一档都没有
      state={
        !state && quota?.success
          ? { kind: "note", text: t("kimi.oauth.noSubscription") }
          : state
      }
      queriedAt={quota?.queriedAt ?? null}
      loading={loading}
      onRefresh={() => void refetch()}
    />
  );
}

/** Antigravity 账号的剩余额度（agy_account_quota(accountId)，不用先切号） */
export function AgyAccountQuota({
  accountId,
  login,
}: {
  accountId: string;
  login: string;
}) {
  const { t, i18n } = useTranslation();
  const display = useQuotaDisplay();
  const {
    data: quota,
    isFetching: loading,
    refetch,
  } = useAgyAccountQuota(accountId, { enabled: true, autoQuery: false });
  return (
    <AccountQuotaColumn
      login={login}
      state={subscriptionQuotaState(t, quota, loading, i18n.language, display)}
      queriedAt={quota?.queriedAt ?? null}
      loading={loading}
      onRefresh={() => void refetch()}
    />
  );
}

/** Claude 官方账号的订阅额度（get_claude_account_quota(accountId)，不用先切号） */
export function ClaudeAccountQuota({
  accountId,
  login,
}: {
  accountId: string;
  login: string;
}) {
  const { t, i18n } = useTranslation();
  const display = useQuotaDisplay();
  const {
    data: quota,
    isFetching: loading,
    refetch,
  } = useClaudeAccountQuota(accountId, { enabled: true, autoQuery: false });
  return (
    <AccountQuotaColumn
      login={login}
      state={subscriptionQuotaState(t, quota, loading, i18n.language, display)}
      queriedAt={quota?.queriedAt ?? null}
      loading={loading}
      onRefresh={() => void refetch()}
    />
  );
}

/**
 * Grok Build (Grok CLI) 预设供应商配置模板
 *
 * 独立维护，与 codexProviderPresets.ts 无数据联动（Jason 2026-07-21 定）。
 * 初始条目取自当时的 Codex 预设快照，此后两边各自演进：
 * 合作伙伴链接 / 图标 / endpoint 变更需要在本文件单独修改。
 *
 * 收录规则：
 * - 不含官方 / 托管 OAuth 预设：Grok CLI 自带 xAI 订阅登录，官方态走
 *   独立的 "Grok Official" 条目（对应 providers_seed.rs 的 seed，
 *   空 config = 不写自定义模型表）。
 * - 不含国产模型官方直连（cn_official）与纯开源模型托管站
 *   （SiliconFlow / ModelScope / Novita / Nvidia / AtlasCloud）：
 *   这些上游没有 Grok 模型，无法在 Grok CLI 中使用。
 * - OpenCode Go 上游自 2026-08 起已提供 grok 系模型（2026-11 时已含
 *   grok-4.7），但暂仍不收录：订阅制网关是否纳入 Grok 预设属产品决策，
 *   收录前需单独评估。
 * - 只收聚合站与第三方中转站，默认模型统一为 grok-4.7（xAI 2026-11 起
 *   的旗舰，context 最高 500k；Grok CLI 自身默认按 256k 处理，模板经
 *   GROK_BUILD_DEFAULT_CONTEXT_WINDOW 显式钉 500k）；
 *   OpenRouter 系命名空间的路由站用 "x-ai/grok-4.7"。
 *
 * config 字段沿用 Codex 风格 TOML 作为载体：Grok 表单只从中提取
 * base_url / model / wire_api 三个字段（extractCodex* 工具），再重建
 * Grok CLI 自己的 config.toml。
 */
import type { ProviderCategory } from "../types";
import type { CodexApiFormat } from "../types";
import { GROK_BUILD_DEFAULT_MODEL } from "../utils/grokBuildConfig";
import type { PresetFamilyFields } from "./presetFamilies";

export interface GrokBuildProviderPreset extends PresetFamilyFields {
  name: string;
  nameKey?: string; // i18n key for localized display name
  websiteUrl: string;
  apiKeyUrl?: string;
  auth: Record<string, any>;
  config: string; // Codex 风格 TOML 载体（只消费 base_url / model / wire_api）
  isOfficial?: boolean;
  isPartner?: boolean;
  partnerPromotionKey?: string;
  category?: ProviderCategory;
  endpointCandidates?: string[];
  icon?: string;
  iconColor?: string;
  apiFormat?: CodexApiFormat;
}

// 官方条目与后端 seed（providers_seed.rs 的 "Grok Official"）对应：
// 空 config = 不写自定义模型表，Grok CLI 回落到自带的 xAI OAuth 登录。
// 预设 id 复用固定 provider id，AddProviderDialog 据此走 ensure seed 流程。
export const grokBuildOfficialPreset: GrokBuildProviderPreset = {
  name: "Grok Official",
  websiteUrl: "https://x.ai/grok",
  isOfficial: true,
  category: "official",
  auth: {},
  config: "",
  icon: "grok",
  iconColor: "currentColor",
};

/** OpenRouter 系命名空间路由站的 Grok 模型 id */
const OPENROUTER_STYLE_GROK_MODEL = "x-ai/grok-4.7";

const grokAuth = (): Record<string, any> => ({ OPENAI_API_KEY: "" });

function grokPresetConfig(
  providerName: string,
  baseUrl: string,
  model = GROK_BUILD_DEFAULT_MODEL,
): string {
  const tomlString = (value: string) => JSON.stringify(value);

  return `model_provider = "custom"
model = ${tomlString(model)}

[model_providers.custom]
name = ${tomlString(providerName)}
base_url = ${tomlString(baseUrl)}
wire_api = "responses"
requires_openai_auth = true`;
}

export const grokBuildProviderPresets: GrokBuildProviderPreset[] = [
  // ===== 赞助商预设：文件顺序与 README 赞助商表对齐（仅维护约定；应用内一律按显示名排序，不置顶）=====
  {
    name: "PackyCode",
    websiteUrl: "https://www.packyapi.ai",
    apiKeyUrl: "https://www.packyapi.ai/register?aff=cc-switch",
    auth: grokAuth(),
    config: grokPresetConfig("PackyCode", "https://www.packyapi.ai/v1"),
    endpointCandidates: [
      "https://www.packyapi.ai/v1",
      "https://cf.api.fan/v1",
      "https://slb-v1.api.fan/v1",
      "https://www.packyapi.com/v1",
    ],
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "packycode",
    icon: "packycode",
  },
  {
    name: "APINebula",
    websiteUrl: "https://apinebula.ai",
    apiKeyUrl: "https://apinebula.ai/VjM74M",
    auth: grokAuth(),
    config: grokPresetConfig("APINebula", "https://apinebula.ai/v1"),
    endpointCandidates: ["https://apinebula.ai/v1"],
    apiFormat: "openai_responses",
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "apinebula",
    icon: "apinebula",
  },
  {
    name: "AICodeMirror",
    websiteUrl: "https://www.aicodemirror.ai",
    apiKeyUrl: "https://www.aicodemirror.ai/register?invitecode=9915W3",
    auth: grokAuth(),
    config: grokPresetConfig(
      "AICodeMirror",
      "https://api.aicodemirror.ai/api/codex/backend-api/codex",
    ),
    endpointCandidates: [
      "https://api.aicodemirror.ai/api/codex/backend-api/codex",
    ],
    isPartner: true,
    partnerPromotionKey: "aicodemirror",
    icon: "aicodemirror",
    iconColor: "#000000",
  },
  {
    name: "PatewayAI",
    websiteUrl: "https://pateway.ai",
    apiKeyUrl: "https://pateway.ai/?ch=etzpm8&aff=WB6M6F67#/",
    auth: grokAuth(),
    config: grokPresetConfig("PatewayAI", "https://api.pateway.ai/v1"),
    endpointCandidates: ["https://api.pateway.ai/v1"],
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "patewayai",
    icon: "pateway",
  },
  {
    name: "hao.ai",
    websiteUrl: "https://hao.ai",
    apiKeyUrl: "https://hao.ai/invite/DTBZS3OR",
    auth: grokAuth(),
    // xAI 协议另有地址 /x-ai/v1（hao.ai/docs/develop/authentication，2026-10-21）
    config: grokPresetConfig(
      "hao.ai",
      "https://api.hao.ai/x-ai/v1",
      "x-ai/grok-4.7",
    ),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "haoai",
    icon: "haoai",
  },
  {
    name: "FennoAI",
    websiteUrl: "https://api.fenno.ai",
    apiKeyUrl:
      "https://api.fenno.ai/register?redirect=/purchase?tab=subscription%26group=16&aff=P9MR3D3PLCNL",
    auth: grokAuth(),
    config: grokPresetConfig("FennoAI", "https://api.fenno.ai"),
    endpointCandidates: ["https://api.fenno.ai"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "fenno",
    icon: "fenno",
  },
  {
    name: "RunAPI",
    websiteUrl: "https://runapi.host",
    apiKeyUrl: "https://runapi.host/register?aff=iOKB",
    auth: grokAuth(),
    config: grokPresetConfig("RunAPI", "https://runapi.host/v1"),
    endpointCandidates: ["https://runapi.host/v1", "https://runapi.co/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "runapi",
    icon: "runapi",
  },
  {
    name: "OpenModel",
    websiteUrl: "https://www.openmodel.ai",
    apiKeyUrl: "https://www.openmodel.ai?ref=cc-switch",
    auth: grokAuth(),
    config: grokPresetConfig("OpenModel", "https://api.openmodel.ai/v1"),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "openmodel",
    icon: "openmodel",
  },
  {
    name: "GrooRoute Pro",
    websiteUrl: "https://grooroute.pro",
    apiKeyUrl: "https://grooroute.pro/sign-up?aff=qqm9",
    auth: grokAuth(),
    config: grokPresetConfig(
      "GrooRoute Pro",
      "https://grooroute.pro/v1",
      "grok-4.7",
    ),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "grooroute",
    icon: "grooroute",
  },
  {
    name: "BuyToken",
    websiteUrl: "https://buytoken.work",
    apiKeyUrl: "https://buytoken.work/sign-up?aff=cc-switch",
    auth: grokAuth(),
    // 须用 grok 分组的 Key；分组里只有 grok-4.7（buytoken.work/pricing，2026-10-23）
    config: grokPresetConfig(
      "BuyToken",
      "https://api.buytoken.work/v1",
      "grok-4.7",
    ),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "buytoken",
    icon: "buytoken",
  },
  {
    name: "V-API",
    websiteUrl: "https://gpt.ge",
    apiKeyUrl: "https://gpt.ge/signup?aff=URNP",
    auth: grokAuth(),
    // grok-4.7 支持 /v1/responses，只在 gf 分组（gpt.ge/models/grok-4.7，2026-10-23）
    config: grokPresetConfig("V-API", "https://api.gpt.ge/v1", "grok-4.7"),
    category: "aggregator",
    // 备用线路取自 gpt.ge/api/status 的 api_list（2026-10-23）
    endpointCandidates: [
      "https://api.gpt.ge/v1",
      "https://api.vveai.com/v1",
      "https://run.v3.cm/v1",
      "https://api1.v3.cm/v1",
      "https://api2.v3.cm/v1",
      "https://us.gpt.ge/v1",
    ],
    isPartner: true,
    partnerPromotionKey: "vapi",
    icon: "vapi",
  },
  {
    name: "Shengsuanyun",
    nameKey: "providerForm.presets.shengsuanyun",
    websiteUrl: "https://www.shengsuanyun.com/?from=CH_4HHXMRYF",
    apiKeyUrl: "https://www.shengsuanyun.com/?from=CH_4HHXMRYF",
    auth: grokAuth(),
    config: grokPresetConfig(
      "Shengsuanyun",
      "https://router.shengsuanyun.com/api/v1",
      OPENROUTER_STYLE_GROK_MODEL,
    ),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "shengsuanyun",
    icon: "shengsuanyun",
  },
  {
    name: "AIGoCode",
    websiteUrl: "https://aigocode.net",
    apiKeyUrl: "https://aigocode.net/invite/CC-SWITCH",
    auth: grokAuth(),
    config: grokPresetConfig("AIGoCode", "https://api.aigocode.dev"),
    endpointCandidates: [
      "https://api.aigocode.dev",
      "https://api.aigocode.app",
    ],
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "aigocode",
    icon: "aigocode",
    iconColor: "#5B7FFF",
  },
  {
    name: "Qiniu",
    nameKey: "providerForm.presets.qiniu",
    websiteUrl: "https://s.qiniu.com/nMvAvy",
    apiKeyUrl: "https://s.qiniu.com/nMvAvy",
    auth: grokAuth(),
    config: grokPresetConfig(
      "Qiniu",
      "https://api.qnaigc.com/bypass/openai/v1",
    ),
    endpointCandidates: [
      "https://api.qnaigc.com/bypass/openai/v1",
      "https://api.modelink.ai/bypass/openai/v1",
    ],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "qiniu",
    icon: "qiniu",
  },
  {
    name: "SubRouter",
    websiteUrl: "https://subrouter.ai",
    apiKeyUrl: "https://subrouter.ai/register?aff=l3ri",
    auth: grokAuth(),
    config: grokPresetConfig("SubRouter", "https://subrouter.ai/v1"),
    endpointCandidates: ["https://subrouter.ai/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "subrouter",
    icon: "subrouter",
  },
  {
    name: "88API",
    websiteUrl: "https://88api.ai",
    apiKeyUrl: "https://88api.ai/sign-up?aff=HSGY",
    auth: grokAuth(),
    config: grokPresetConfig("88API", "https://api.88api.ai/v1"),
    endpointCandidates: ["https://api.88api.ai/v1", "https://88api.ai/v1"],
    apiFormat: "openai_responses",
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "88api",
    icon: "88api",
  },
  {
    name: "APIKEY.FUN",
    websiteUrl: "https://apikey.fan",
    apiKeyUrl: "https://apikey.fan/register?aff=CCSwitch",
    auth: grokAuth(),
    config: grokPresetConfig("APIKEY.FUN", "https://api.apikey.fan/v1"),
    endpointCandidates: [
      "https://api.apikey.fan/v1",
      "https://api.apikey.fun/v1",
      "https://slb.apikey.fun/v1",
    ],
    apiFormat: "openai_responses",
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "apikeyfun",
    icon: "apikeyfun",
  },
  {
    name: "9527CODE",
    websiteUrl: "https://9527.codes",
    apiKeyUrl: "https://9527.codes/register?aff=e5zI",
    auth: grokAuth(),
    config: grokPresetConfig("9527CODE", "https://9527.codes/v1"),
    endpointCandidates: [
      "https://9527.codes/v1",
      "https://api.9527.codes/v1",
      "https://cdn.9527.codes/v1",
    ],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "9527code",
    icon: "9527code",
  },
  {
    name: "Code0",
    websiteUrl: "https://code0.ai",
    apiKeyUrl: "https://code0.ai/agent/register/B2XHxGjGmRvqgznY",
    auth: grokAuth(),
    config: grokPresetConfig("Code0", "https://code0.ai/v1"),
    endpointCandidates: ["https://code0.ai/v1"],
    category: "aggregator",
    icon: "code0",
  },
  {
    name: "TeamoRouter",
    websiteUrl: "https://teamorouter.cn",
    apiKeyUrl:
      "https://teamorouter.cn/?utm_source=cc_switch&utm_medium=referral&utm_campaign=ai_directory",
    auth: grokAuth(),
    config: grokPresetConfig("TeamoRouter", "https://api.teamorouter.cn/v1"),
    endpointCandidates: [
      "https://api.teamorouter.cn/v1",
      "https://api.teamorouter.com/v1",
    ],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "teamorouter",
    icon: "teamorouter",
  },
  {
    name: "ClaudeCN",
    websiteUrl: "https://claudecn.top",
    apiKeyUrl: "https://claudecn.ai/register?aff=HEL9",
    auth: grokAuth(),
    config: grokPresetConfig("ClaudeCN", "https://claudecn.top/v1"),
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "claudecn",
    icon: "claudecn",
  },
  {
    name: "A6API",
    websiteUrl: "https://www.a6api.vip",
    apiKeyUrl: "https://a6api.vip/register?aff=AqNr",
    auth: grokAuth(),
    config: grokPresetConfig("A6API", "https://api.a6api.vip/v1"),
    endpointCandidates: ["https://api.a6api.vip/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "a6api",
    icon: "a6api",
  },
  {
    name: "Compshare",
    family: "compshare",
    planKey: "payg",
    nameKey: "providerForm.presets.ucloud",
    websiteUrl: "https://www.compshare.cn",
    apiKeyUrl:
      "https://www.compshare.cn/coding-plan?ytag=GPU_YY_YX_git_cc-switch",
    auth: grokAuth(),
    config: grokPresetConfig("Compshare", "https://api.modelverse.cn/v1"),
    endpointCandidates: ["https://api.modelverse.cn/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "ucloud",
    icon: "ucloud",
    iconColor: "#000000",
  },
  {
    name: "Compshare Coding Plan",
    family: "compshare",
    planKey: "codingPlan",
    nameKey: "providerForm.presets.ucloudCoding",
    websiteUrl: "https://www.compshare.cn",
    apiKeyUrl:
      "https://www.compshare.cn/coding-plan?ytag=GPU_YY_YX_git_cc-switch",
    auth: grokAuth(),
    config: grokPresetConfig(
      "Compshare Coding Plan",
      "https://cp.compshare.cn/v1",
    ),
    endpointCandidates: ["https://cp.compshare.cn/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "ucloud",
    icon: "ucloud",
    iconColor: "#000000",
  },
  {
    name: "CCSub",
    websiteUrl: "https://www.ccsub.net",
    apiKeyUrl: "https://www.ccsub.net/register?ref=Y6Z8DXEA",
    auth: grokAuth(),
    config: grokPresetConfig("CCSub", "https://www.ccsub.net/v1"),
    endpointCandidates: ["https://www.ccsub.net/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "ccsub",
    icon: "ccsub",
  },
  {
    name: "SSSAiCode",
    websiteUrl: "https://sssaicodeapi.com",
    apiKeyUrl: "https://sssaicodeapi.com/register?ref=DCP0SM",
    auth: grokAuth(),
    config: grokPresetConfig(
      "SSSAiCode",
      "https://node-hk.sssaicodeapi.com/api/v1",
    ),
    endpointCandidates: [
      "https://node-hk.sssaicodeapi.com/api/v1",
      "https://node-hk.sssaiapi.com/api/v1",
      "https://node-cf.sssaicodeapi.com/api/v1",
    ],
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "sssaicode",
    icon: "sssaicode",
    iconColor: "#000000",
  },
  {
    name: "SoleAPI",
    websiteUrl: "https://soleapi.com",
    apiKeyUrl: "https://soleapi.com/r/ccswitch",
    auth: grokAuth(),
    config: grokPresetConfig("SoleAPI", "https://soleapi.com/v1"),
    endpointCandidates: ["https://soleapi.com/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "soleapi",
    icon: "soleapi",
  },
  {
    name: "Micu",
    websiteUrl: "https://www.micuapi.ai",
    apiKeyUrl: "https://www.micuapi.ai/register?aff=aOYQ",
    auth: grokAuth(),
    config: grokPresetConfig("Micu", "https://www.micuapi.ai/v1"),
    endpointCandidates: ["https://www.micuapi.ai/v1"],
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "micu",
    icon: "micu",
    iconColor: "#000000",
  },
  {
    name: "RightCode",
    websiteUrl: "https://www.rightapi.ai",
    apiKeyUrl: "https://www.rightapi.ai/register?aff=CCSWITCH",
    auth: grokAuth(),
    config: grokPresetConfig("RightCode", "https://www.rightapi.ai/codex/v1"),
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "rightcode",
    icon: "rc",
    iconColor: "#E96B2C",
  },
  {
    name: "Cubence",
    websiteUrl: "https://cubence.com",
    apiKeyUrl: "https://cubence.com/signup?code=CCSWITCH&source=ccs",
    auth: grokAuth(),
    config: grokPresetConfig("Cubence", "https://api.cubence.com/v1"),
    endpointCandidates: [
      "https://api.cubence.com/v1",
      "https://api-cf.cubence.com/v1",
      "https://api-dmit.cubence.com/v1",
      "https://api-bwg.cubence.com/v1",
    ],
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "cubence",
    icon: "cubence",
    iconColor: "#000000",
  },
  {
    name: "CrazyRouter",
    websiteUrl: "https://www.crazyrouter.com",
    apiKeyUrl: "https://www.crazyrouter.com/register?aff=OZcm&ref=cc-switch",
    auth: grokAuth(),
    config: grokPresetConfig("CrazyRouter", "https://cn.crazyrouter.com/v1"),
    endpointCandidates: ["https://cn.crazyrouter.com/v1"],
    isPartner: true,
    partnerPromotionKey: "crazyrouter",
    icon: "crazyrouter",
    iconColor: "#000000",
  },
  {
    name: "DMXAPI",
    websiteUrl: "https://www.dmxapi.cn",
    auth: grokAuth(),
    config: grokPresetConfig("DMXAPI", "https://www.dmxapi.cn/v1"),
    endpointCandidates: ["https://www.dmxapi.cn/v1"],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "dmxapi",
    icon: "dmxapi",
  },
  {
    name: "SudoCode.chat",
    family: "sudocode",
    websiteUrl: "https://sudocode.chat",
    apiKeyUrl:
      "https://sudocode.chat/sign-up?aff=CC-SWITCH&utm_source=cc-switch&utm_medium=sponsor&utm_campaign=ccswitch",
    auth: grokAuth(),
    config: grokPresetConfig("SudoCode.chat", "https://api.sudocode.chat/v1"),
    endpointCandidates: [
      "https://api.sudocode.chat/v1",
      "https://api.sudorelay.com/v1",
    ],
    apiFormat: "openai_responses",
    category: "third_party",
    isPartner: true,
    partnerPromotionKey: "sudocode",
    icon: "sudocode",
  },
  {
    name: "SudoCode.us",
    family: "sudocode",
    websiteUrl: "https://sudocode.us",
    apiKeyUrl: "https://sudocode.us",
    auth: grokAuth(),
    config: grokPresetConfig("SudoCode.us", "https://sudocode.us/v1"),
    endpointCandidates: ["https://sudocode.us/v1", "https://sudocode.run/v1"],
    apiFormat: "openai_responses",
    category: "third_party",
    isPartner: true,
    icon: "sudocode-us",
  },
  {
    name: "Modelflare",
    websiteUrl: "https://modelflare.dev",
    apiKeyUrl:
      "https://modelflare.dev/sign-up?utm_medium=referral&utm_source=ccswitch",
    auth: grokAuth(),
    // 官方 Grok Build 文档（docs.modelflare.dev/guides/clients/grok-build，
    // 2026-10-15 核对）：Responses + /v1、grok-4.5
    config: grokPresetConfig("Modelflare", "https://modelflare.dev/v1"),
    endpointCandidates: [
      "https://modelflare.dev/v1",
      "https://origin.modelflare.dev/v1",
    ],
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "modelflare",
    icon: "modelflare",
  },
  {
    name: "AllTokens",
    websiteUrl: "https://alltokens.cc",
    apiKeyUrl: "https://alltokens.cc/register",
    auth: grokAuth(),
    // Sub2API 网关：Key 绑定单个分组，须用 Grok 分组的 Key（分组与模型见
    // alltokens.cc/api/v1/model-plaza，2026-10-17 核对）
    config: grokPresetConfig("AllTokens", "https://alltokens.cc/v1"),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "alltokens",
    icon: "alltokens",
  },
  {
    name: "AllTokens SI",
    websiteUrl: "https://alltokens.si",
    // 站点关闭了个人注册（/api/status 的 register_enabled=false），只能企业注册
    apiKeyUrl: "https://alltokens.si/enterprise-register",
    auth: grokAuth(),
    // Grok 分组不在默认自动分组里，须用 Grok 分组的 Key；分组没有 grok-4.5，
    // 取 grok-4.7（alltokens.si/api/pricing，2026-10-19 核对）
    config: grokPresetConfig(
      "AllTokens SI",
      "https://alltokens.si/v1",
      "grok-4.7",
    ),
    category: "aggregator",
    isPartner: true,
    partnerPromotionKey: "alltokens_si",
    icon: "alltokens-si",
  },
  // ===== 非赞助商预设：应用内展示按显示名排序，此处文件顺序不影响展示 =====
  {
    name: "Tu-zi",
    nameKey: "providerForm.presets.tuzi",
    websiteUrl: "https://api.tu-zi.com",
    apiKeyUrl: "https://api.tu-zi.com/token",
    auth: grokAuth(),
    config: grokPresetConfig("Tu-zi", "https://api.tu-zi.com/v1"),
    endpointCandidates: [
      "https://api.tu-zi.com/v1",
      "https://api.ourzhishi.top/v1",
      "https://api.sydney-ai.com/v1",
      "https://apicdn.tu-zi.com/v1",
    ],
    apiFormat: "openai_responses",
    category: "aggregator",
    icon: "tuzi",
  },
  {
    name: "xAI (Grok)",
    websiteUrl: "https://x.ai/api",
    apiKeyUrl: "https://console.x.ai",
    auth: grokAuth(),
    config: grokPresetConfig("xAI (Grok)", "https://api.x.ai/v1", "grok-4.7"),
    endpointCandidates: ["https://api.x.ai/v1"],
    apiFormat: "openai_responses",
    category: "third_party",
    icon: "xai",
    iconColor: "#000000",
  },
  {
    name: "Amux",
    websiteUrl: "https://amux.ai",
    apiKeyUrl: "https://amux.ai",
    auth: grokAuth(),
    config: grokPresetConfig("Amux", "https://api.amux.ai/v1"),
    endpointCandidates: ["https://api.amux.ai/v1"],
    category: "aggregator",
    icon: "amux",
  },
  {
    name: "AiHubMix",
    websiteUrl: "https://aihubmix.com",
    auth: grokAuth(),
    config: grokPresetConfig("AiHubMix", "https://aihubmix.com/v1"),
    endpointCandidates: [
      "https://aihubmix.com/v1",
      "https://api.aihubmix.com/v1",
    ],
    category: "aggregator",
    icon: "aihubmix",
    iconColor: "#006FFB",
  },
  {
    name: "CherryIN",
    websiteUrl: "https://open.cherryin.ai",
    apiKeyUrl: "https://open.cherryin.ai/console/token",
    auth: grokAuth(),
    config: grokPresetConfig(
      "CherryIN",
      "https://open.cherryin.net/v1",
      OPENROUTER_STYLE_GROK_MODEL,
    ),
    endpointCandidates: ["https://open.cherryin.net/v1"],
    category: "aggregator",
    icon: "cherryin",
  },
  {
    name: "RelaxyCode",
    websiteUrl: "https://www.relaxycode.com",
    apiKeyUrl: "https://www.relaxycode.com/register",
    auth: grokAuth(),
    config: grokPresetConfig("RelaxyCode", "https://www.relaxycode.com/v1"),
    category: "third_party",
    icon: "relaxcode",
  },
  {
    name: "E-FlowCode",
    websiteUrl: "https://e-flowcode.cc",
    apiKeyUrl: "https://e-flowcode.cc",
    auth: grokAuth(),
    config: grokPresetConfig("E-FlowCode", "https://e-flowcode.cc/v1"),
    endpointCandidates: ["https://e-flowcode.cc/v1"],
    category: "third_party",
    icon: "eflowcode",
    iconColor: "#000000",
  },
  {
    name: "PIPELLM",
    websiteUrl: "https://code.pipellm.ai",
    apiKeyUrl: "https://code.pipellm.ai/login?ref=uvw650za",
    auth: grokAuth(),
    config: grokPresetConfig("PIPELLM", "https://cc-api.pipellm.ai/v1"),
    endpointCandidates: ["https://cc-api.pipellm.ai/v1"],
    category: "aggregator",
    icon: "pipellm",
  },
  {
    name: "OpenRouter",
    websiteUrl: "https://openrouter.ai",
    apiKeyUrl: "https://openrouter.ai/keys",
    auth: grokAuth(),
    config: grokPresetConfig(
      "OpenRouter",
      "https://openrouter.ai/api/v1",
      OPENROUTER_STYLE_GROK_MODEL,
    ),
    category: "aggregator",
    icon: "openrouter",
    iconColor: "#6566F1",
  },
  {
    name: "TheRouter",
    websiteUrl: "https://therouter.ai",
    apiKeyUrl: "https://dashboard.therouter.ai",
    auth: grokAuth(),
    config: grokPresetConfig(
      "TheRouter",
      "https://api.therouter.ai/v1",
      // TheRouter 的 xAI 前缀是 xai/（不是 x-ai/）
      "xai/grok-4.7",
    ),
    endpointCandidates: ["https://api.therouter.ai/v1"],
    category: "aggregator",
    icon: "therouter",
  },
  {
    name: "SoruxGPT",
    websiteUrl: "https://ai.soruxgpt.com",
    apiKeyUrl: "https://ai.soruxgpt.com/console/token",
    auth: grokAuth(),
    config: grokPresetConfig("SoruxGPT", "https://ai.soruxgpt.com/v1"),
    endpointCandidates: [
      "https://ai.soruxgpt.com/v1",
      "https://api-cf.soruxgpt.com/v1",
      "https://api-host.soruxgpt.com/v1",
      "https://api-node6.soruxgpt.com/v1",
      "https://api-node3.soruxgpt.com/v1",
    ],
    category: "aggregator",
    icon: "soruxgpt",
  },
  {
    name: "IKunCode",
    websiteUrl: "https://api.ikuncode.ai",
    apiKeyUrl: "https://api.ikuncode.ai/console/token",
    auth: grokAuth(),
    config: grokPresetConfig("IKunCode", "https://api.ikuncode.ai/v1"),
    endpointCandidates: [
      "https://api.ikuncode.ai/v1",
      "https://api.ikuncode.cc/v1",
    ],
    category: "aggregator",
    icon: "ikuncode",
  },
  {
    name: "RunToken",
    websiteUrl: "https://www.runtoken.ai",
    apiKeyUrl: "https://www.runtoken.ai/console/token",
    auth: grokAuth(),
    config: grokPresetConfig("RunToken", "https://www.runtoken.ai/v1"),
    endpointCandidates: [
      "https://www.runtoken.ai/v1",
      "https://fast.runtoken.ai/v1",
    ],
    category: "aggregator",
    icon: "runtoken",
  },
  {
    name: "BotCF",
    websiteUrl: "https://botcf.com",
    apiKeyUrl: "https://botcf.com/console/token",
    auth: grokAuth(),
    config: grokPresetConfig("BotCF", "https://botcf.com/v1"),
    category: "aggregator",
    icon: "botcf",
  },
  {
    name: "YYLX",
    nameKey: "providerForm.presets.yylx",
    websiteUrl: "https://yylx.io",
    apiKeyUrl: "https://app.yylx.io/keys",
    auth: grokAuth(),
    config: grokPresetConfig("YYLX", "https://app.yylx.io/v1"),
    endpointCandidates: [
      "https://app.yylx.io/v1",
      "https://global.yylx.io/v1",
      "https://cn.yylx.io/v1",
    ],
    category: "aggregator",
    icon: "yylx",
  },
  {
    name: "TokenFlux",
    websiteUrl: "https://tokenflux.com",
    apiKeyUrl: "https://tokenflux.com/keys",
    auth: grokAuth(),
    config: grokPresetConfig("TokenFlux", "https://tokenflux.com/v1"),
    category: "aggregator",
    endpointCandidates: [
      "https://tokenflux.com/v1",
      "https://tokenflux.dev/v1",
    ],
    icon: "tokenflux",
  },
  {
    name: "AIComing",
    websiteUrl: "https://aicoming.top",
    apiKeyUrl: "https://aicoming.top/console#keys",
    auth: grokAuth(),
    config: grokPresetConfig("AIComing", "https://api.aicoming.top/v1"),
    category: "aggregator",
    icon: "aicoming",
  },
];
